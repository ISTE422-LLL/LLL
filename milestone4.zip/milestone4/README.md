1. Download the milestone4.zip folder, make sure you place the folder in Desktop

2. Unzip the folder

3. Open Terminal

4. Type:   cd Desktop/milestone4/milestone4

5. Press Enter

6. Type:   java -cp milestone4.jar RunEdgeConvert

7. Press Enter

8. Click on Help tap, you will see two more options
