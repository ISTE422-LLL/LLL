1. Download the milestone5.zip folder, make sure you place the folder in Desktop
2. Unzip the folder
3. Open Terminal
4. Type: 	cd Desktop/milestone5
5. Type:   java -cp milestone5.jar RunEdgeConvert

Note:
When you �Create DDL�, make sure you select the �Source Code� folder which contain the codes
