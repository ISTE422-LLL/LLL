1. Download the milestone3.zip folder, make sure you place the folder in Desktop

2. Unzip the folder

3. Open Terminal

4. Type:   cd Desktop/milestone3/milestone3

5. Press Enter

6. Type:   java -cp Milestone3.jar RunEdgeConvert

7. Press Enter

8. Now you will see the GUI pop up, please click on the File → Open Edge File

9. Now you will see another window pop up, please click on the Desktop/ → milestone3/ →milestone3/ →  Courses.edg → Ok

10. Now, what we expect to see is 
	STUDENT
	FACULTY
	COURSES 
    In both GUI and Terminal. 
